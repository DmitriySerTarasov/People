import taxes.Company;

public class Main {
    public static void main(String[] args) {
        String title;
        int debit;
        int credit;
        int taxSystem;
        Company company = new Company();

    }

}