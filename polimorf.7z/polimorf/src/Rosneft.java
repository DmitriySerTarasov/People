public class Rosneft {
}
