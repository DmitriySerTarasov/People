public class Rzd {
    String title = "Российские железные дороги";
    int debit = 10000;
    int credit = 2000;
    int taxSystem = debit * 6 / 100;


    public void shiftMoney(int amount) {
        int amount = 0;
            int amount = debit - credit;
        if (amount > 0) {
            debit * amount);
        } else {
            if (amount < 0) {
                credit * Math.abs(amount)
            } else {
                if (amount == 0) {
                    return;
                }
            }
        }
    }
}