package taxes;
class TaxSystem{
    public int calcTaxFor(int debit, int credit) {
        return 0;
    }
}
public class Company {
    protected String title;
    protected int debit;
    protected int credit;
    protected int taxSystem;

    public class Rzd {
        Rzd rzd = new Rzd();



}
public class rosneft {
        Rosneft rosneft = new Rosneft();
    }
}
